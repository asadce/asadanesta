var $ = jQuery;
$(function() {
    $("#at_biz_dir-tags").val('GOLD LEVEL');
});// JavaScript Document