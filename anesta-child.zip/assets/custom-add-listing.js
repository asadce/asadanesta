//var $ = jQuery;
//$(document).ready(function(){
//$(function () {
//    var gold = $(".dwpp_gold .btn").attr("data-active_status");
//    var silver = $(".dwpp_silver .btn").attr("data-active_status");
//    var bronze = $(".dwpp_bronze .btn").attr("data-active_status");
//    var business = $(".dwpp_business .btn").attr("data-active_status");
//    console.log(gold);
//    console.log(silver);
//    console.log(bronze);
//    console.log(business);
//    if (gold == "yes" || silver == "yes" || bronze == "yes" || business == "yes") {
//        window.location.replace("/directory-dash/#active_dashboard_my_listings");
//        console.log("redirect")
//    }
//        
//    if (gold != "yes" && silver != "yes" && bronze != "yes" && business != "yes") {
//        $(".page-template-plans-template .page_content_wrap").css({"visibility":"visible"});
//        console.log("make visible")
//    }
//});
//    });
//
//
//$(document).ready(function(){
//var maxheight = 0;
//
//$('.atbd_plan_col').each(function () {
//    maxheight = ($(this).height() > maxheight ? $(this).height() : maxheight); 
//});
//
//$('.atbd_plan_col').height(maxheight);
//    });